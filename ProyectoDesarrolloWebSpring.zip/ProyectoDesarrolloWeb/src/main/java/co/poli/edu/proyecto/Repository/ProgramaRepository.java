package co.poli.edu.proyecto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import co.poli.edu.proyecto.Model.Programa;


public interface ProgramaRepository extends JpaRepository<Programa, String>{

}
