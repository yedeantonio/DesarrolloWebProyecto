package co.poli.edu.proyecto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.poli.edu.proyecto.Model.Pasantia;

public interface PasantiaRepository extends JpaRepository<Pasantia, Integer>{

}
