package co.poli.edu.proyecto.Service;

import co.poli.edu.proyecto.Model.*;

public interface MailService {

	public void sendEmail (Mail mail);
	
}
