package co.poli.edu.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoDesarrolloWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoDesarrolloWebApplication.class, args);
	}

}
